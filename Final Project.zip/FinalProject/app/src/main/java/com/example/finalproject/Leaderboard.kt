package com.example.finalproject

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.firebase.Firebase
import com.google.firebase.firestore.firestore
import com.google.firestore.v1.StructuredAggregationQuery.Aggregation.Count
import java.nio.charset.MalformedInputException


class Leaderboard : AppCompatActivity() {
    private lateinit var percentileText : TextView
    private lateinit var adView : AdView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.leaderboard)

        percentileText = findViewById(R.id.percentile_text)
        val prefs = MainActivity.sharedPref
        var country : String = prefs.getString(MainActivity.PREFERENCE_COUNTRY, "null")!!
        country = CountryCodes.countryAlpha2Map[country.lowercase()]!!.lowercase()

        adView = AdView( this )
        var adSize : AdSize = AdSize( AdSize.FULL_WIDTH, AdSize.AUTO_HEIGHT )
        adView.setAdSize(adSize )
        var adUnitId : String = "ca-app-pub-3940256099942544/6300978111"
        adView.adUnitId = adUnitId

        var builder : AdRequest.Builder = AdRequest.Builder()
        builder.addKeyword("fitness")
        var request : AdRequest = builder.build()

        var adLayout = findViewById<LinearLayout>(R.id.ad_view)
        adLayout.addView(adView)
        adView.loadAd(request)

        val db = Firebase.firestore
        val scores = db.collection("countries").document(country)
        scores.get().addOnSuccessListener { document ->
            if (document != null && document.exists()) {
                val countryData = document.data
                countryData?.let {
                    var list = ArrayList<Long>()
                    var score = (-1).toLong()

                    for ((username, value) in countryData) {
                        list.add(value as Long)

                        if (username == prefs.getString(MainActivity.PREFERENCE_USER, "null")) {
                            score = value as Long
                        }

                        Log.w("test","Key: $username, Value: $value")
                    }
                    list.sortDescending()
                    val rank = list.indexOfLast { it == score } + 1
                    val percentile = (rank.toDouble()/list.size) * 100
                    Log.w("test", "scored in the $percentile percentile")
                    percentileText.text = "You have scored in the ${percentile.toInt()} percentile!"
                }
            } else {
                // Document doesn't exist
                Log.w("test","No such document")
            }
        }
        .addOnFailureListener { exception ->
            // Error fetching document
            Log.e("test","Error getting document: $exception")
        }

        val mainMenuButton : Button = findViewById(R.id.menu_button)
        mainMenuButton.setOnClickListener(View.OnClickListener { v -> onMainMenuClick() })

    }

    fun onMainMenuClick(){
        val intent = Intent(this, MainActivity::class.java)
        startActivity(intent)
    }
}