package com.example.finalproject

import android.content.Intent
import android.content.SharedPreferences
import android.content.res.ColorStateList
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.Gravity
import android.view.KeyEvent
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TableLayout
import android.widget.TableRow
import android.widget.TextView
import android.widget.Toast
import androidx.core.view.marginStart
import com.google.firebase.Firebase
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.firestore.SetOptions
import com.google.firebase.firestore.firestore

class GameActivity : AppCompatActivity() {
    private lateinit var input : EditText
    private lateinit var table : TableLayout
    private lateinit var submit : Button
    private lateinit var test : TextView
    private var guesses : ArrayList<String> = ArrayList()
    private lateinit var imageView: ImageView
    var numGuesses = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.game)

        input = findViewById(R.id.userInput)
        table = findViewById(R.id.allGuesses)
        submit = findViewById(R.id.submit)
        submit.setBackgroundColor(Color.RED)
        imageView = findViewById(R.id.country)

        input.setOnEditorActionListener { _, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_DONE ||
                    (event.action == KeyEvent.ACTION_DOWN && event.keyCode == KeyEvent.KEYCODE_ENTER)
            ) {
                onSubmit()
                true
            } else {
                false // Return false to let the system handle the event
            }
        }

        val prefs = MainActivity.sharedPref
        val editor : SharedPreferences.Editor = MainActivity.sharedPref.edit()
        editor.putString(MainActivity.PREFERENCE_COUNTRY, MainActivity.countriesList[prefs.getInt(MainActivity.PREFERENCE_INDEX, 0)][0])
        editor.apply()

        val countryName = MainActivity.sharedPref.getString(MainActivity.PREFERENCE_COUNTRY, "null")
        val code = CountryCodes.countryAlpha2Map[countryName]!!.lowercase()
        val resourceId = resources.getIdentifier(code, "raw", packageName)
        imageView.setImageResource(resourceId)
        Log.w("test", "$code")
        submit.setOnClickListener { onSubmit() }
    }

    fun onSubmit() {
        if (numGuesses == 5) {
            val editor : SharedPreferences.Editor = MainActivity.sharedPref.edit()
            editor.putInt(MainActivity.PREFERENCE_INDEX, MainActivity.sharedPref.getInt(MainActivity.PREFERENCE_INDEX, -1) + 1)
            editor.apply()
            val toast : Toast = Toast.makeText(this, "All guesses used!", Toast.LENGTH_SHORT)
            toast.show()
            finish()
        }


        val guess = input.text.toString()
        if (!CountryCodes.countriesAndCapitals.containsKey(guess.lowercase())) {
            val toast : Toast = Toast.makeText(this, "No such country in our list!", Toast.LENGTH_SHORT)
            toast.show()
            return
        }
        if (guesses.contains(guess.lowercase())) {
            val toast : Toast = Toast.makeText(this, "Already guessed!", Toast.LENGTH_SHORT)
            toast.show()
            return
        }
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(input.windowToken, 0)
        guesses.add(guess.lowercase())
        numGuesses++
        val row = TableRow(this)
        val progressRow = TableRow(this)
        val params = TableLayout.LayoutParams(TableLayout.LayoutParams.MATCH_PARENT, TableLayout.LayoutParams.WRAP_CONTENT)
        params.bottomMargin = 10
        row.layoutParams = params

        val guessTV = TextView(this)
        guessTV.text = guess
        guessTV.gravity = Gravity.START

        guessTV.setBackgroundResource(R.drawable.guess_background)
        guessTV.layoutParams = TableRow.LayoutParams(0, TableRow.LayoutParams.WRAP_CONTENT, 2f)
        if (guess.equals(MainActivity.sharedPref.getString(MainActivity.PREFERENCE_COUNTRY, "null"), ignoreCase = true)) {
            val editor : SharedPreferences.Editor = MainActivity.sharedPref.edit()
            editor.putInt(MainActivity.PREFERENCE_INDEX, MainActivity.sharedPref.getInt(MainActivity.PREFERENCE_INDEX, -1) + 1)
            editor.apply()
            //CONTINUE THIS
            var firebase : FirebaseDatabase = FirebaseDatabase.getInstance()
            val db = Firebase.firestore
            val countriesRef = db.collection("countries")
            val correctGuess = hashMapOf(MainActivity.sharedPref.getString(MainActivity.PREFERENCE_USER, "null") to numGuesses)
            val countryCode = CountryCodes.countryAlpha2Map[MainActivity.sharedPref.getString(MainActivity.PREFERENCE_COUNTRY, "null")]!!.lowercase()
            db.collection("countries").document(countryCode).set(correctGuess, SetOptions.merge())
            val intent = Intent(this, Leaderboard::class.java)
            startActivity(intent)
        } else {
            val distanceTV = TextView(this)
            val distCalc = Distance(this)
            distCalc.getDistance(guess, MainActivity.sharedPref.getString(MainActivity.PREFERENCE_COUNTRY, "null").toString())
            distanceTV.text = "${(distCalc.getResults()[0] / 1000).toInt().toString()} KM"
            distanceTV.gravity = Gravity.CENTER
            //        distanceTV.textSize = 20f
            distanceTV.setBackgroundResource(R.drawable.guess_background)
            val paramsTV = TableRow.LayoutParams(0, TableRow.LayoutParams.WRAP_CONTENT, 1f)
            paramsTV.marginStart = 10

            val progressBar : ProgressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)

            // Set the progress range (0-100 in this case)
            progressBar.max = 100

            // Set the initial progress
            var progress = ((((distCalc.getResults()[0] / 1000)) * -100)/20000 + 100).toInt()
            if (progress < 0) progress = 0
            Log.w("test", "$progress")
            progressBar.progress = progress
            if (progress < 30) {
                progressBar.progressTintList = ColorStateList.valueOf(Color.RED)
            } else if (progress < 75) {
                progressBar.progressTintList = ColorStateList.valueOf(Color.YELLOW)
            } else {
                progressBar.progressTintList = ColorStateList.valueOf(Color.GREEN)
            }


            distanceTV.layoutParams = paramsTV
            val correctTV = TextView(this)
            //correctTV.text = "X"
            correctTV.gravity = Gravity.END
//        distanceTV.textSize = 20f
            correctTV.setBackgroundColor(Color.RED)
            correctTV.layoutParams = paramsTV
            row.addView(guessTV)
            row.addView(distanceTV)
            val distanceTV2 = TextView(this)
            val guessTV2 = TextView(this)
            progressRow.layoutParams = params
            progressRow.addView(guessTV2)
            progressRow.addView(distanceTV2)
            progressRow.addView(progressBar)
        }
        table.addView(row)
        table.addView(progressRow)
    }
}