package com.example.finalproject

import android.content.Context
import android.graphics.Color
import android.location.Address
import android.location.Geocoder
import android.location.Location
import android.util.Log
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.model.CircleOptions
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.google.gson.annotations.SerializedName
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Path
import java.util.concurrent.CountDownLatch

class Distance {
    private lateinit var map : GoogleMap
    private lateinit var geocoder: Geocoder
    private lateinit var geocoderHandler: GeocodeHandler
    private var fromFlag = false
    private var from : LatLng? = null
    private var to : LatLng? = null
    private var results = FloatArray(1)

    constructor(context : Context) {
        geocoder = Geocoder(context)
        val address = "University of Maryland College Park"
        geocoderHandler = GeocodeHandler()

    }

    fun getResults() : FloatArray = results

    fun getDistance(start: String, end: String): Double {
        val latch = CountDownLatch(2)
        Log.w("test", "here")
        val list = CountryCodes.countriesAndCapitals
        val capitalStart = CountryCodes.countriesAndCapitals[start.lowercase()]
        val capitalEnd = CountryCodes.countriesAndCapitals[end.lowercase()]

        geocoder.getFromLocationName("${CountryCodes.countriesAndCapitals[start.lowercase()]}, $start",10) { addresses ->
            if (!fromFlag) {
                from = LatLng(addresses[0].latitude, addresses[0].longitude)
                fromFlag = true
            }
            latch.countDown()
        }

        geocoder.getFromLocationName("${CountryCodes.countriesAndCapitals[end.lowercase()]}, $end",10) { addresses ->
            if (fromFlag) {
                to = LatLng(addresses[0].latitude, addresses[0].longitude)
                fromFlag = false
                results = FloatArray(1)
                Location.distanceBetween(from!!.latitude, from!!.longitude, to!!.latitude, to!!.longitude, results)
            }
            latch.countDown()
        }

        // Wait for both geocoder calls to finish
        latch.await()

        return results[0].toDouble()
    }

    inner class GeocodeHandler : Geocoder.GeocodeListener {
        override fun onGeocode(addresses: MutableList<Address>) {
            if (!fromFlag) {
                from = LatLng(addresses[0].latitude, addresses[0].longitude)
                fromFlag = true
            } else {
                fromFlag = false
                to = LatLng(addresses[0].latitude, addresses[0].longitude)
                results = FloatArray(1)
                Location.distanceBetween(from!!.latitude, from!!.longitude, to!!.latitude, to!!.longitude, results)
            }
            val latitude = addresses.get(0).latitude
            val longitude = addresses.get(0).longitude
            Log.w("MainActivity", "lat: $latitude, long: $longitude")
        }

    }
}