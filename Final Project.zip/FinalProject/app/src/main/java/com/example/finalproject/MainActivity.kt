package com.example.finalproject

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.Firebase
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.firestore.SetOptions
import com.google.firebase.firestore.firestore


class MainActivity : AppCompatActivity() {

    private lateinit var imageView : ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val toast : Toast = Toast.makeText(this, "Click on the image for instructions!", Toast.LENGTH_LONG)
        toast.show()
        imageView = findViewById(R.id.appIcon)

        imageView.setOnClickListener{ showDialog(this, "Instructions", "Guess the country based on the image. You have 6 guesses. Good luck!") }

        for ((key, value) in CountryCodes.countryAlpha2Map.entries) {
            val pair: MutableList<String> = ArrayList()
            pair.add(key)
            pair.add(value)
            countriesList.add(pair)
        }


        var firebase : FirebaseDatabase = FirebaseDatabase.getInstance()
        val db = Firebase.firestore
        val countriesRef = db.collection("countries")

        val countryCode = "bf"

        var distCalc = Distance(this)
        distCalc.getDistance("Burkina Faso", "Ethiopia")
        // on incorrect guess submisison


        // on correct guess submission
        var numGuesses = 3
        val correctGuess = hashMapOf("user3" to numGuesses)
        db.collection("countries").document(countryCode).set(correctGuess, SetOptions.merge())
        var pref : SharedPreferences = this.getSharedPreferences(this.packageName + "_preferences", Context.MODE_PRIVATE)
        sharedPref = pref
//        val editor : SharedPreferences.Editor = sharedPref.edit()
//        editor.putInt(PREFERENCE_INDEX, sharedPref.getInt(PREFERENCE_INDEX, -1) - 1)
//        editor.apply()
        if (sharedPref.getInt(PREFERENCE_INDEX, -1) == -1) {
            val editor : SharedPreferences.Editor = sharedPref.edit()
            editor.putInt(PREFERENCE_INDEX, 0)
            editor.apply()
        }



        val updateButton : Button = findViewById(R.id.update)
        updateButton.setOnClickListener(View.OnClickListener { v -> onUpdateUserClick() })

        val startGameButton : Button = findViewById(R.id.start)
        startGameButton.setOnClickListener(View.OnClickListener { v -> onStartGameClick() })

        if (sharedPref.getString(PREFERENCE_USER, "no username") != "no username"){
            val usernameEditText : EditText = findViewById(R.id.username)
            usernameEditText.setText(sharedPref.getString(PREFERENCE_USER, "no username")?.
            substringBefore('_'))

            updateButton.text = "Change User"
        }

//        val intent = Intent(this, Leaderboard::class.java)
//        startActivity(intent)
    }

    fun showDialog(context: Context, title: String, message: String) {
        val builder = AlertDialog.Builder(context)
        builder.setTitle(title)
        builder.setMessage(message)
        builder.setPositiveButton("OK") { dialog, _ ->
            // Dismiss the dialog when OK button is clicked
            dialog.dismiss()
        }
        val dialog = builder.create()
        dialog.show()
    }



    fun onStartGameClick(){
        if (sharedPref.getString(PREFERENCE_USER, "no username") == "no username"){
            var toast : Toast = Toast.makeText(this, "No Username", Toast.LENGTH_SHORT)
            toast.show()
            return
        }
        //Start the Game Activity
        val intent = Intent(this, GameActivity::class.java)
        startActivity(intent)
    }

    fun onUpdateUserClick(){
        val usernameEditText : EditText = findViewById(R.id.username)
        if (usernameEditText.text.toString() == ""){
            var toast : Toast = Toast.makeText(this, "No Username", Toast.LENGTH_SHORT)
            toast.show()
            return
        }

        val editor : SharedPreferences.Editor = sharedPref.edit()
        editor.putString(PREFERENCE_USER, "${usernameEditText.text.toString()}_${(System.nanoTime()/1000).toString()}")
        editor.apply()
    }

    companion object {
        var countriesList : ArrayList<List<String>> = ArrayList()
        lateinit var sharedPref : SharedPreferences
        const val PREFERENCE_USER : String = "user"
        const val PREFERENCE_COUNTRY : String = "country"
        const val PREFERENCE_INDEX : String = "index"
    }
}